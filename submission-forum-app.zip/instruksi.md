Tujuan Akhir
Buatlah aplikasi React bertemakan “Aplikasi Forum Diskusi” yang memanfaatkan API dari Dicoding Forum API https://forum-api.dicoding.dev/v1/#/. Kami mengedepankan kreativitas Anda dalam membangun aplikasi, tetapi pastikan aplikasi yang dibuat memenuhi kriteria yang dijelaskan di bawah ini.


Kriteria Utama 1: Fungsionalitas Aplikasi
    Terdapat cara untuk mendaftar akun.
    Terdapat cara untuk login akun.
    Menampilkan daftar thread.
    Ketika item thread dipilih, menampilkan detail thread beserta komentar di dalamnya.
    Pengguna dapat membuat thread.
    Pengguna dapat membuat komentar di dalam sebuah thread.
    Menampilkan Loading Indicator ketika memuat data dari API.

Catatan penting.

    Perihal authorization dalam mengakses resource threads kami bebaskan. Anda boleh mengharuskan pengguna untuk login ataupun tidak ketika ingin melihat threads. Namun, dalam berinteraksi mengubah data, seperti membuat thread atau komentar, pengguna wajib terotentikasi.
    Item thread pada halaman daftar thread yang ditampilkan harus mengandung informasi berikut ini.
        Judul dari thread.
        Potongan dari body thread (opsional).
        Waktu pembuatan thread.
        Jumlah komentar.
        Informasi pembuat thread:
            Nama
            Avatar (opsional)
    Halaman detail thread harus mengandung informasi berikut ini.
        Judul dari thread.
        Body dari thread.
        Waktu pembuatan thread.
        Informasi pembuat thread:
            Nama
            Avatar
    Komentar pada thread tersebut. Minimal informasi yang harus ditampilkan adalah:
        Konten dari komentar.
        Waktu pembuatan komentar.
        Informasi pembuat komentar:
            Nama
            Avatar (opsional)


Kriteria Utama 2: Bugs Highlighting
    Menggunakan ESLint pada source code aplikasi. Indikasinya adalah terdapat berkas konfigurasi ESLint pada proyek.
    Menerapkan salah satu Code Convention berikut.
        Dicoding Academy JavaScript Style Guide.
        AirBnB JavaScript Style Guide.
        Google JavaScript Style Guide.
        StandardJS Style Guide.
    Tidak ada indikasi error yang ditampilkan ESLint.
    Menggunakan React Strict Mode.


Kriteria Utama 3: Arsitektur Aplikasi
    Hampir seluruh state aplikasi (terutama yang bersumber dari API) disimpan pada Redux Store. Form input atau controlled component diperbolehkan untuk mengelola state-nya sendiri.
    Tidak ada pemanggilan REST API yang dilakukan di dalam lifecycle atau efek pada komponen.
    Memisahkan kode UI dengan State di folder yang terpisah.
    React component bersifat modular dan reusable.


Buat Proyekmu Unggul!
    Selain kriteria utama yang wajib Anda penuhi, kami beri beberapa saran yang bisa Anda terapkan agar proyek lebih unggul dan mendapat nilai terbaik.

Saran 1: Fitur Votes pada Thread dan Komentar
    Menyediakan tombol yang dapat digunakan untuk votes pada thread dan komentar.
    Menampilkan indikasi pada tombol bila pengguna sudah mem-vote thread dan komentar. Contohnya, mengubah warna tombol dari abu-abu menjadi merah bila pengguna sudah up-vote/down-vote.
    Mengedepankan User Experience dengan menerapkan Optimistically Apply Actions.
    Menampilkan jumlah votes pada thread dan komentar.

Saran 2: Menampilkan Leaderboard
    Terdapat halaman untuk menampilkan leaderboard.
    Setiap item leaderboard, harus menampilkan informasi berikut ini.
        Nama pengguna.
        Avatar pengguna.
        Score.

Saran 3: Filter Daftar Thread Berdasarkan Kategori
    Terdapat fitur untuk mem-filter item thread yang ditampilkan pada halaman daftar threads.
    
Catatan: API tidak menyediakan endpoint untuk filter daftar threads, sehingga fitur ini dibangun murni dari sisi Front-End dengan memanipulasi state aplikasi.



Contoh Aplikasi
Kami mendorong Anda untuk berkreasi dalam mengerjakan proyek submission dengan menambahkan atau menetapkan gaya secara mandiri. Namun, berikut gambaran besar dari aplikasi yang perlu Anda buat.
https://dicoding-forum-app.vercel.app/
Hindari meniru persis contoh aplikasi. Inilah waktu yang tepat untuk mengasah kemampuan dan kreativitas Anda dalam membangun proyek.

Ikuti instruksi berikut agar lebih mudah dalam mengerjakan submission.

Buat Rencana yang Matang
    Buat sketsa dari aplikasi yang akan dibuat
    Dalam mengerjakan proyek ini, Anda perlu menentukan visual berdasarkan fungsionalitas aplikasi. Salah satu cara terbaik adalah dengan menggambar tiap halaman aplikasi menggunakan kertas dan pensil. Hal ini akan sangat membantu Anda untuk memberikan ide informasi yang harus ada pada setiap halaman aplikasi.

    Selain dengan kertas dan pensil, Anda juga bisa memanfaatkan aplikasi mock-up gratis seperti Figma.

Pecah view menjadi hierarki komponen
    Setelah menggambar tiap halaman aplikasi, Anda bisa tandai yang bisa dijadikan komponen terpisah dengan memberi garis kotak. Ini akan memudahkan Anda dalam menentukan hierarki komponennya.

Tentukan Action yang dapat terjadi pada aplikasi
    Anda perlu menganalisis action yang mungkin terjadi pada aplikasi terhadap sebuah data. Contohnya, menetapkan nilai state dari API atau menambah dan memodifikasi state. Ini akan memudahkan Anda dalam menentukkan state dan action yang harus dibuat pada aplikasi.

Fase Coding
    Buatlah folder baru untuk memulai proyek React. Kami sarankan Anda untuk menggunakan [create-react-app](https://react.dev/learn/creating-a-react-app) agar tidak perlu repot menyiapakan module bundler dan lain sebagainya.
    Pasanglah dependencies yang sudah pasti dibutuhkan seperti redux atau redux toolkit, react-redux, dan lainnya. Jangan dulu pasang dependencies yang sekiranya belum Anda butuhkan.
    Buatlah kode yang berhubungan dengan state terlebih dulu, seperti action dan reducer. Kemudian buatlah Redux store dan daftarkan seluruh reducer yang sudah dibuat.
    Uji Redux Store dan pastikan bekerja dengan baik. Anda bisa mengeceknya via console terlebih dulu.
    Buatlah komponen dan pastikan store berfungsi dengan baik ketika digunakan pada komponen.
    Tambahkan react-router jika Anda sudah membutuhkannya.
    Selesaikan aplikasi berdasarkan kriteria yang ada.

Jika Anda sudah berpengalaman dalam membangun aplikasi, Anda bisa menyesuaikan alur yang cocok dengan kebutuhan Anda sendiri.

Peringatan!
Jangan lupa untuk mengambil jeda untuk beristirahat karena ketika badan dan pikiran segar, pekerjaan yang Anda lakukan akan lebih berkualitas. Estimasi pengerjaan proyek ini adalah 20 jam. Jika Anda meluangkan waktu 2 jam dalam 1 hari, Anda bisa menyelesaikan dalam 10 hari.

Submission ini tidak didesain untuk dikerjakan secara maraton.

Submission akan dinilai oleh reviewer dalam skala 1-5. Untuk mendapatkan nilai tinggi, Anda bisa menerapkan beberapa saran berikut.

    Menerapkan Saran 1: Fitur Votes pada Thread dan Komentar.
    Menerapkan Saran 2: Menampilkan Leaderboard.
    Menerapkan Saran 3: Filter Daftar Thread Berdasarkan Kategori.
        Saran lainnya:
        Aplikasi yang Anda bangun mudah untuk digunakan. Contohnya, tidak membuat pengguna bingung dan menggunakan warna yang mudah dalam membaca teks.
        Aplikasi yang Anda bangun memiliki tampilkan yang menarik.